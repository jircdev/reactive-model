System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      _export("default", {
        "package": "@beyond-js/reactive",
        "version": "0.0.3",
        "languages": {
          "default": "en",
          "supported": ["en", "es"]
        },
        "global.css": true,
        "layout": "main-layout",
        "params": {},
        "ssr": {},
        "backend": {}
      });
    }
  };
});