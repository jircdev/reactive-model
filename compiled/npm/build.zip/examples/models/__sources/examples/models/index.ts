import { DBManager } from "@beyond-js/reactive/database";

(async () => {})();
