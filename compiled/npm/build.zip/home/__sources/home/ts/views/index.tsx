import * as React from "react";

export /*bundle*/
function Page(): JSX.Element {
	return (
		<div className="page__container">
			<h1>Hola felix</h1>
		</div>
	);
}
