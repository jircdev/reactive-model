/************
Processor: ts
************/

// index.ts
declare namespace ns_0 {}



export declare const hmr: {on: (event: string, listener: any) => void, off: (event: string, listener: any) => void };